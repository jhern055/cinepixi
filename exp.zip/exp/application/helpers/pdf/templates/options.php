<?php

	return array(

		// "series_relation_page"=>"mostrar página individual de relación de series ( sólo aplica si existe alguna serie )",
		// "article_description_eight_words"=>"cortar la descripción de articulo a 8 palabras",
		// "print_on_currency_usd"=>"imprimir en dólares ( sólo aplica si se especificó el tipo de cambio )",
		// "include_comment"=>"Incluir comentarios",
		// "include_all_client_payment_methods"=>"Incluir leyenda con todos los métodos de pago del cliente ( sólo aplica si se especificó un método de pago asociado al cliente y existe más de uno )",
		// "include_promissory"=>"Incluir pagare",
		// "title_bill_receipt_of_fees"=>"Titulo: Recibo de Honorarios",
		// "title_bill_receipt_of_lease"=>"Titulo: Recibo de Arrendamiento",
		// "include_attachments_to_send"=>"incluir adjuntos",
		// "include_seller"=>"Incluir el vendedor",
		// "include_currency"=>"Incluir tipo de cambio",
		// "show_discounts"=>"Ocultar descuentos",

	);

?>
