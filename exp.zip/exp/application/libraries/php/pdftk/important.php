<?php/*

the file pdftk.php was modified to work on windows enviroments, check CODEID "COAD08822" for details.

*/?>