<?php

return array(

	"xmlns"=>"http://www.sat.gob.mx/cfd/2",
	"xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance",
	"xsi:schemaLocation"=>"http://www.sat.gob.mx/cfd/2 http://www.sat.gob.mx/sitio_internet/cfd/2/cfdv22.xsd",

);

?>